def count_in_list(list, item):
    return list.count(item)

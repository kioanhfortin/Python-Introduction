#ft_package

This is a simple Python package for educational purposes.